# Using deploy api

deploy hook usage:

https://github.com/Neilpang/acme.sh/wiki/deployhooks

