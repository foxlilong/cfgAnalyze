# How to use DNS API
DNS api usage:

https://github.com/Neilpang/acme.sh/wiki/dnsapi